﻿namespace ApiProject2.Models;

public class CreateProductImageDTO
{
    public int ProductId { get; set; }

    public int ImageId { get; set; }
}
