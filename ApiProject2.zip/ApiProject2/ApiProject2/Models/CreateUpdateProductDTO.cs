﻿namespace ApiProject2.Models;

public class CreateUpdateProductDTO
{
    public string? Name { get; set; }
    public string? Description { get; set; }
    public decimal Price { get; set; }
    public decimal Tax { get; set; }
    public string? IsDiscountable { get; set; }
    public int CategoryId { get; set; }
}
