﻿namespace ApiProject2.Models;

public class CreateProductSpecificationDTO
{
    public int Id { get; set; }
    public string? Specification { get; set; }
    public int ProductId { get; set; }
}
