﻿namespace ApiProject2.Models;

public enum ImageType
{
    Jpg = 1,
    Png = 2,
    Jpeg = 3,
    Webp = 4
}
