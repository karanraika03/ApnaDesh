﻿using ApiProject2.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebApplication1.Models;

namespace ApiProject2.Controllers;

[Route("api/[controller]")]
[ApiController]
public class ProductSpecificationControllers : ControllerBase
{
    private readonly DataContext _context;
    public ProductSpecificationControllers(DataContext context)
    {
        _context = context;
    }
    [HttpPost]
    public void Post(CreateProductSpecificationDTO input)
    {
        var productSpecification = new ProductSpecification
        {
            Specification = input.Specification,
            ProductId = input.ProductId
        };
        _context.ProductSpecifications.Add(productSpecification);
        _context.SaveChanges();
    }
    [HttpGet]
    public List<ProductSpecification> get()
    {
        return _context.ProductSpecifications.ToList();
    }
    [HttpPut("{id}")]
    public void put(int id, CreateProductSpecificationDTO input)
    {
        ProductSpecification productSpecification = _context.ProductSpecifications.Find(id);

        if (productSpecification != null)
        {
            productSpecification.Specification = input.Specification;
            productSpecification.ProductId = input.ProductId;

            _context.ProductSpecifications.Update(productSpecification);
            _context.SaveChanges();
        }
    }
    [HttpDelete("{id}")]
    public void Delete(int id)
    {
        ProductSpecification productSpecification = _context.ProductSpecifications.Find(id);

        if (productSpecification != null)
        {
            _context.ProductSpecifications.Remove(productSpecification);
            _context.SaveChanges();
        }

    }
}

