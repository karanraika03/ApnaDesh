﻿using ApiProject2.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebApplication1.Models;

namespace ApiProject2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductControllers : ControllerBase
    {
        private readonly DataContext _context;

        public ProductControllers(DataContext context)
        {
            _context = context;
        }
        [HttpPost]
        public void post(CreateUpdateProductDTO input)
        {
            var product = new Product
            {
                Name = input.Name,
                Description = input.Description,
                Price = input.Price,
                Tax = input.Tax,
                IsDiscountable = input.IsDiscountable,
                CategoryId = input.CategoryId
            };
            _context.Products.Add(product);
            _context.SaveChanges();
        }
        [HttpGet]
        public List<Product> Get()
        {
            return _context.Products.ToList();
        }
        [HttpPut("{id}")]
        public void Put(int id,CreateUpdateProductDTO input)
        {
            Product product = _context.Products.Find(id);

            if (product != null)
            {
                product.Name = input.Name;
                product.Description = input.Description;
                product.Price = input.Price;
                product.Tax = input.Tax;
                product.IsDiscountable = input.IsDiscountable;
                product.CategoryId = input.CategoryId;
                _context.Products.Update(product);
                _context.SaveChanges();
            }
        }
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
            Product product = _context.Products.Find(id);

            if (product != null)
            {
                _context.Products.Remove(product);
                _context.SaveChanges();
            }

        }
    }
}
