﻿using ApiProject2.Models;
using Microsoft.AspNetCore.Mvc;
using WebApplication1.Models;

[Route("api/[controller]")]
[ApiController]
public class ImageController : ControllerBase
{
    private readonly DataContext _context;

    public ImageController(DataContext context)
    {
        _context = context;
    }
    [HttpPost]
    public void post(CreateImageUpdateDTO input)
    {
        var Image = new Image
        {
            Name = input.Name,
            Url = input.Url,
            ImageType = input.ImageType
        };
        _context.Images.Add(Image);
        _context.SaveChanges();
    }
    [HttpGet]
    public List<Image> Get()
    {
        return _context.Images.ToList();
    }
    [HttpPut("{id}")]
    public void Put(int id, CreateImageUpdateDTO input)
    {
        Image image = _context.Images.Find(id);

        if (image != null)
        {
            image.Name = input.Name;
            image.Url = input.Url;
            image.ImageType = input.ImageType;

            _context.Images.Update(image);
            _context.SaveChanges();
        }
    }
    [HttpDelete("{id}")]
    public void Delete(int id)
    {
        Image image = _context.Images.Find(id);

        if (image != null)
        {
            _context.Images.Remove(image);
            _context.SaveChanges();
        }

    }
}