﻿using ApiProject2.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebApplication1.Models;

namespace ApiProject2.Controllers;

[Route("api/[controller]")]
[ApiController]
public class ProductImageControllers : ControllerBase
{
    private readonly DataContext _context;

    public ProductImageControllers(DataContext context)
    {
        _context = context;
    }
    [HttpPost]
    public void post(CreateProductImageDTO input)
    {
        var ProductImage = new ProductImage
        {
            ProductId = input.ProductId,
            ImageId = input.ImageId
        };
        _context.ProductImages.Add(ProductImage);
        _context.SaveChanges();
    }
    [HttpGet]
    public List<ProductImage> Get()
    {
        return _context.ProductImages.ToList();
    }
    [HttpPut("{id}")]
    public void Put(int id, CreateProductImageDTO input)
    {
        ProductImage ProductImage = _context.ProductImages.Find(id);

        if (ProductImage != null)
        {
            ProductImage.ProductId = input.ProductId;
            ProductImage.ImageId = input.ImageId;

            _context.ProductImages.Update(ProductImage);
            _context.SaveChanges();
        }
    }
    [HttpDelete("{id}")]
    public void Delete(int id)
    {
        ProductImage ProductImage = _context.ProductImages.Find(id);

        if (ProductImage != null)
        {
            _context.ProductImages.Remove(ProductImage);
            _context.SaveChanges();
        }

    }
}
