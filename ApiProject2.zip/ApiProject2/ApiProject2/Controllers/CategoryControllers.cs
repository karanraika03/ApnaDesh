﻿using ApiProject2.Models;
using Microsoft.AspNetCore.Mvc;
using WebApplication1.Models;

namespace ApiProject2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CategoryControllers : ControllerBase
    {
        private readonly DataContext _context;

        public CategoryControllers(DataContext context)
        {
            _context = context;
        }
        [HttpPost]
        public void post(Category input )
        {
            _context.Categories.Add(input);
            _context.SaveChanges();
        }
        [HttpGet]
        public List<Category> Get()
        {
            return _context.Categories.ToList();
        }
        [HttpPut("{id}")]
        public void Put(int id, Category input)
        {
            Category category = _context.Categories.Find(id);

            if (category != null)
            {
                category.Name = input.Name;
                category.Description = input.Description;
                category.image = input.image;
                _context.SaveChanges();
            }
        }
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
            Category category = _context.Categories.Find(id);

            if (category != null)
            {
                _context.Categories.Remove(category);
                _context.SaveChanges();
            }

        }
    }
}
