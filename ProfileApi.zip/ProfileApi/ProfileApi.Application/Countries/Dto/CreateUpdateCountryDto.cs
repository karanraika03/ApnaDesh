﻿namespace ProfileApi.Countries;

public class CreateUpdateCountryDto
{
    public string Name { get; set; }
}
